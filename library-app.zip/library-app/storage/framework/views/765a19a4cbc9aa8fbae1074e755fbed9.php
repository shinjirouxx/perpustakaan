<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
      .book_label
      {
        color: white;
        padding: 30px;
        font-size: 30px;
        font-weight: bold;
      }

      .book_deg
      {
        text-align: center;
        margin: auto;
      }

      .book_div
      {
        padding: 15px;
      }

      label
      {
        display: inline-block;
        width: 200px;
      }
    </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex align-items-stretch">

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <div class="book_deg">
                <h1 class="book_label">Update Book</h1>

                <form action="<?php echo e(url('update_book', $data->id)); ?>" method="Post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                    <div class="book_div">
                        <label>Book Title</label>
                        <input type="text" name="title" value="<?php echo e($data->title); ?>">
                    </div>

                    <div  class="book_div">
                        <label>Author Name</label>
                        <input type="text" name="author_name" value="<?php echo e($data->author_name); ?>">
                    </div>

                    <div class="book_div">
                        <label>Price</label>
                        <input type="text" name="price" value="<?php echo e($data->price); ?>">
                    </div>

                    <div class="book_div">
                        <label>Quantity</label>
                        <input type="number" name="quantity" value="<?php echo e($data->quantity); ?>">
                    </div>

                    <div class="book_div">
                        <label>Description</label>
                        <textarea name="description"><?php echo e($data->description); ?></textarea>
                    </div>

                    <div class="book_div">
                        <label>Category</label>
                        <select name="category">
                          <option value="<?php echo e($data->category_id); ?>"><?php echo e($data->category->cat_title); ?></option>

                          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->cat_title); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div class="book_div">
                          <label>Current Author Image</label>
                          <img style="width: 100px; border-radius: 50%; margin: auto;" src="/pfp/<?php echo e($data->author_img); ?>">
                        </div>

                        <div class="book_div">
                          <label>Change Author Image</label>
                          <input type="file" name="author_img">
                        </div>

                        <div class="book_div">
                          <label>Current Book Image</label>
                          <img style="width: 100px; margin: auto;" src="/book/<?php echo e($data->book_img); ?>">
                        </div>

                        <div class="book_div">
                          <label>Change Book Image</label>
                          <input type="file" name="book_img">
                        </div>

                        <input type="submit" class="btn btn-info" value="Update Book">
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>
    
    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\daren\projects\library-app\resources\views/admin/edit_book.blade.php ENDPATH**/ ?>