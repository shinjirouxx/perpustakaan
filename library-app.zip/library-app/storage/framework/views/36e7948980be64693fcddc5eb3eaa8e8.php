<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <style type="text/css">
        .div_center
        {
            text-align:center;
            margin:auto;
        }

        .cat_label
        {
            font-size: 30px;
            font-weight: bold;
            padding: 30px;
            color: white;
        }

        .center
        {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 50px;
            border: 1px solid white;
        }

        th
        {
            background-color: skyblue;
            padding: 10px;
        }

        tr
        {
            border: 1px solid white;
            padding: 10px
        }
    </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex align-items-stretch">

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <div class="div_center">
                <div>
                    <?php if(session()->has('message')): ?>

                    <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>


                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    </div>

                    <?php endif; ?>
                </div>

                <h1 class="cat_label">Add Category</h1>

                <form action="<?php echo e(url('add_category')); ?>" method="Post">

                    <?php echo csrf_field(); ?>

                    <span style="padding-right: 15px">
                    <label>Category Name</label>

                    <input type="text" name="category" required>
                    </span>

                    <input class="btn btn-primary" type="submit" value="Add Category">
                </form>
                <div>
                    <table class="center">
                        <tr>
                            <th>
                                Category Name
                            </th>
                            <th>
                                Action
                            </th>
                        </tr>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($data->cat_title); ?>

                            </td>
                            <td>
                                <a class="btn btn-info" href="<?php echo e(url('edit_category', $data->id)); ?>">Update</a>

                                <a onclick="confirmation(event)" class="btn btn-danger" href="<?php echo e(url('cat_delete', $data->id)); ?>">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
          </div>
        </div>
    </div>
    
    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript">
        function confirmation(ev) {
            ev.preventDefault();
            var urlToRedirect = ev.currentTarget.getAttribute('href');
            console.log(urlToRedirect);

            swal({
                title: "Are you sure you want to delete this?",
                text: "There's no turning back.",
                icon: "Warning",
                buttons: true,
                dangerMode: true,
            })

            .then((willCancel)) => {
                if(willCancel) {
                    window.location.href = urlToRedirect;
                }
            }
        }
    </script>
  </body>
</html><?php /**PATH C:\Users\daren\projects\library-app\resources\views/admin/category.blade.php ENDPATH**/ ?>