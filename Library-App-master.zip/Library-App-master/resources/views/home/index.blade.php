<!DOCTYPE html>
<html lang="en">

  <head>
    @include('home.css')
  </head>

<body>

  @include('home.header')

  @include('home.banner')
  
  @include('home.category')

  @include('home.market')

  @include('home.footer')
  </body>
</html>